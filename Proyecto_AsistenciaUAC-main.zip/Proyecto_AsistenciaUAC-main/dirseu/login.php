<?php
session_start();

// Simulación de usuarios y contraseñas (esto normalmente sería de una base de datos)
$usuarios = [
    'alumno@example.com' => password_hash('password1', PASSWORD_DEFAULT), // Alumno
    'docente@example.com' => password_hash('password2', PASSWORD_DEFAULT)  // Docente
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_var($_POST['username'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Validar credenciales
    if (isset($usuarios[$username]) && password_verify($password, $usuarios[$username])) {
        // Almacenar el rol en la sesión
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role;

        // Redireccionar según el rol
        if ($role === 'alumno') {
            header('Location: eventoest.html'); // Página del alumno
        } elseif ($role === 'docente') {
            header('Location: eventos.html'); // Página del docente
        }
        exit();
    } else {
        // Manejar el error de autenticación
        echo "<script>alert('Credenciales incorrectas.');</script>";
    }
}
?>
